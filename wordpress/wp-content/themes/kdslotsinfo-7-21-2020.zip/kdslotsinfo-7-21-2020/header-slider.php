<!-- Element Owl Carousel-->
<div class="col-md-8 col-sm-8 order-slider content-slider">
    <div class="owl-carousel owl-theme" id="owl-demo">
        <div class="item">
            <a href="https://kdslots.co/" target="blank_">
                <div class="img-owl-slide img-owl-no-1"></div>
            </a>
        </div>
        <div class="item">
            <a href="https://kdslots.co/" target="blank_">
                <div class="img-owl-slide img-owl-no-2"></div>
            </a>
        </div>
        <div class="item">
            <a href="https://kdslots.co/" target="blank_">
                <div class="img-owl-slide img-owl-no-3"></div>
            </a>
        </div>
        <div class="item">
            <a href="https://kdslots.co/" target="blank_">
                <div class="img-owl-slide img-owl-no-4"></div>
            </a>
        </div>
    </div>
</div>
<!-- Element Framebox-->
<div class="col-md-4 col-sm-4 order-iframe">
    <div class="framebox">
        <a href="https://www.youtube.com/embed/gc2HVa2Rv84" target="blank_">
            <div>
                <img src="<?php bloginfo('template_url'); ?>/assets/img/misc/play-button.png">
            </div>
        </a>
    </div>
</div>