<!-- Element Text Caution-->
<div class="col-md-12 text-info-caution order-text-caution">
    <p class="centered-text white-normal">
        INFO : PERHATIKAN REKENING AKTIF KDSLOTS DI MENU DEPOSIT AGAR MEMPERMUDAH UNTUK PROSES DEPOSIT ANDA.
    </p>
</div>
<!-- Element Footer Bank-->
<div class="col-md-12 order-footer-bank">
    <!-- Footer Bank -->
    <?php get_footer('bank') ?>
    <!-- End Footer Bank -->
</div>
<!-- Element Bank Status -->
<div class="col-md-12 order-footer-bank-status">
    <div class="centered-text white-normal">
	Bank Online (<div class="indicator-bank online"></div>)
	Bank Gangguan (<div class="indicator-bank trouble"></div>)
	Bank Offline (<div class="indicator-bank offline"></div>) 
    </div>
</div>

<!-- Element Accordion-->
<!-- NAVS -->
<?php get_footer('accordion') ?>
<!-- END NAVS -->

<!-- Element Copyright -->
<div class="col-md-12 order-footer-copy">
    <p class="centered-text white-normal">
        &copy; <a href="https://kdslots.co/"> KDSLOTS</a> | <a href="https://kdslots.co/slots"> SLOTS ONLINE </a> | <a href="https://kdslots.co/casino"> CASINO ONLINE </a> | <a href="https://kdslots.co/poker"> POKER ONLINE </a> | <a href="https://kdslots.co/"> BOLA ONLINE </a> | HAK CIPTA DILINDUNGI.
    </p>
</div>